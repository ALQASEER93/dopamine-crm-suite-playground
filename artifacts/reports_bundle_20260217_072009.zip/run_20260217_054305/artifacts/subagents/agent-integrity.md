﻿# Agent-integrity audit

## Finding 1: Lifecycle fields editable through /api/v1/visits/{id}
- Reference: CRM/backend/api/v1/visits.py:575-637 (update_visit) exposes status, started_at, ended_at, and duration_seconds to every request that passes the sales_manager, medical_rep, or admin dependency.
- Impact: A medical rep can call this endpoint and flip a visit to completed (or retropay timestamps) without hitting the GPS/accuracy-validated start_visit/end_visit paths, defeating geofence enforcement and duration integrity.
- Suggested patch:
  1. Detect lifecycle_fields = {'status','started_at','ended_at','duration_seconds'} early in update_visit and skip applying them unless the caller is promoted (e.g., sales_manager/admin) or explicitly flagged for a lifecycle correction.
  2. Route non-lifecycle updates through the existing start_visit/end_visit helpers so that geofence, accuracy, and max-distance guards still run; only allow PUT to mutate notes, samples_given, next_action, etc.
  3. Document and enforce the new flow in the OpenAPI schema (e.g., keep the existing VisitUpdate schema but strip lifecycle fields or mark them as admin-only overrides).
- Tests:
  - CRM/backend/tests/test_visits.py: add calls where a medical rep PUT /api/v1/visits/{id} with status or ended_at and expect 403 or 400; verify admins (or requests that explicitly opt-in to overrides) can still adjust durations when needed and _sync_duration still runs.

## Finding 2: /api/v1/pwa/visits allows arbitrary timestamp/status creation with only bearer auth
- Reference: CRM/backend/api/v1/pwa.py:14-242 (APIRouter depends only on get_current_user, and create_visit sets status, visitedAt, started_at, ended_at, and coordinates directly from the payload).
- Impact: Any token holder (including internal service accounts or leaked credentials with minimal privileges) can craft a completed visit by supplying status = success and visitedAt, bypassing GPS/accuracy validation completely because the route never calls validate_accuracy/validate_geofence. There is also no role gating to prevent non-sales roles from calling it.
- Suggested patch:
  1. Upgrade the router dependency to Depends(require_roles('medical_rep', 'sales_manager', 'admin')) so only authorized field reps/managers can hit it.
  2. Restrict the permitted status values (default to scheduled) and treat visitedAt as a soft hint; only allow the payload to advance to completed when the server confirms both started_at and ended_at are present and optionally matches a GPS-validated session.
  3. If the offline PWA must support fast completion, centralize the GPS/accuracy checks in a shared helper and reuse it in both /start and /end and the PWA creation path so that accidental bypasses are impossible.
- Tests:
  - CRM/backend/tests/test_pwa_endpoints.py: assert that an admin/service token without a sales role receives 403 for POST /api/v1/pwa/visits and that a medical rep now has to send a payload that either leaves lifecycle fields unset (defaulting to scheduled) or includes the approved override structure.
  - Add regression tests ensuring that supplying status = success still results in the same saved state for permitted roles.

## Finding 3: Legacy Express /api/visits routes expose lifecycle mutations to every authenticated user
- Reference: CRM/backend/legacy-express/index.js:82-99 mounts the router with only requireAuth, and routes/visits.js:744-813 performs no role check before allowing PUT/DELETE operations beyond ensuring a rep cannot touch another rep's visit.
- Impact: Any valid JWT bearer (even a help-desk or finance user) can call the legacy PUT/DELETE endpoints and change status/duration fields because there is no requireRole guard. This directly undermines the integrity guarantees of the new API.
- Suggested patch:
  1. Update index.js to mount the router with app.use('/api/visits', requireAuth, requireRole(['sales_manager', 'sales_rep', 'medical-sales-rep']), visitsRouter); or inject a middleware inside routes/visits.js to reject non-authorized roles before resolving repContext.
  2. Consider adding an explicit hasAnyRole(req.user, ['sales_rep', 'medical-sales-rep', 'sales_manager']) guard inside the router so that the Express layer mirrors the FastAPI restrictions.
- Tests:
  - CRM/backend/tests/test_rbac_sensitive_endpoints.py: add a scenario where a token for an unauthorized role (e.g., support or admin without the listed slugs) hits PUT /legacy/api/visits/:id and receives 403, while a sales rep can still update their own visit through the legacy path.

## Summary
The above gaps allow lifecycle timestamps/status/duration to be edited outside the guarded start/end helpers or by unauthorized roles. Constraining lifecycle mutations to approved roles (and to the GPS/accuracy-validated code paths) restores the integrity guarantees for /api/v1/visits, /api/v1/pwa/visits, and the legacy Express surface.
