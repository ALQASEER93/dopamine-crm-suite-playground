# Agent-PWA Offline Audit (2026-02-17) 
 
## Scope 
- Audit the manual offline queue (src/pwa/offline/queue.ts) + hook (src/pwa/hooks/useOfflineQueue.ts) through the visits screen (routes/visits/VisitsPage.tsx, components/sync/SyncStatus.tsx). 
- Examine background/runtime decisions (service worker runtime caching in vite.config.ts) and how conflicts/duplicate retries are surfaced to the rep. 
- Focus on duplicate prevention, sync status/backoff, and conflict UX with concrete, minimal-diff improvements. 
 
## Findings
1. **Offline queue reliability and duplication:** enqueueMutation builds the idempotency key via JSON.stringify(payload) and then uses it to dedupe.
This is fragile: JS object key order or embedded timestamps change the serialization, so the queue either dedups incorrectly or never dedups even when the payload is logically identical.
There is also no shared tracking between the service worker background sync entry in vite.config.ts and the manual queue, meaning the same POST may be sent twice (service worker request has no X-Idempotency-Key header).
Requeued mutations also never expire—replayQueuedMutations simply re-inserts every failure forever, so a malformed request keeps clogging the queue and the UI (failed count only shows how many lastError strings exist, not how many permanent failures exist).
MAX_QUEUE_LENGTH only trims the oldest items, so a single bad mutation can keep coming back.

2. **Conflict UX is opaque:** Conflicts are detected server-side (404/409/422) and thrown away (sendQueuedMutation returns { ok: true, conflict: true }), queue.ts increments lastConflictAt, and SyncStatus only renders the timestamp.
Officers never see which visit conflicted, no guidance is offered on whether they should re-open the visit, and the visits page message displayed after syncNow is just totals.
There is no way in the UI to tell whether a pending mutation is likely to conflict or permanently failed, so reps cannot resolve key visit data.

3. **Sync-status/backoff visibility is limited:** useOfflineQueue exposes queueCount, failedCount, lastSyncAt, lastConflictAt, isOnline, and isSyncing, but none of these fields expose the nextRetryAt, retryCount, or lastError captured in the queue.
The SyncStatus component simply shows totals and a button, so the rep cannot tell if the queue is waiting for backoff or already failing repeatedly.
Clicking the manual مزامنة الآن button while still offline also fires syncNow, which replays the entire queue even though replayQueuedMutations already scheduled retries—this can overwhelm the UI with repeated fetches.

4. **Timeout/backoff/loop prevention is incomplete:** Exponential backoff lives in replayQueuedMutations, but there is no maxRetryCount (or visibility of one) to stop a permanent failure.
The nextRetryAt is stored on each mutation, but syncNow immediately retries everything whose nextRetryAt is in the past; there is no jitter or spread to prevent a storm when many mutations fail at once.
lastError is overwritten every time, so the UI never learns about the first failure reason and always assumes the server will eventually accept it.

5. **Runtime caching duplication with background sync:** The Vite PWA plugin already configures backgroundSync for the same endpoints that the manual offline queue enqueues (visits/*/start, visits/*/end, etc.).
Because those POST requests pass through NetworkOnly + Workbox background sync, both the service worker queue and the in-app queue will attempt to send the same data on reconnect, with different headers (service worker sends without X-Idempotency-Key).
That means either duplicate server calls or dropped manual retries, and the two queues never reconcile, making the behavior unpredictable.

## Recommendations (minimal-diff)
1. Stabilize deduplication + add failure caps in src/pwa/offline/queue.ts
   - Replace JSON.stringify(payload) with a deterministic serializer (sort keys, drop ephemeral timestamps, or hash type+endpoint+canonicalPayload).
   - Keep idempotencyKey on every queued entry so the service worker (if kept) can reuse it; add a MAX_RETRY_COUNT constant (e.g., 5) and mark mutations as failed once they exceed it.
   - Minimal diff: add a canonicalizePayload helper, declare const MAX_RETRY = 5, and guard replayQueuedMutations to stop re-queuing once retryCount >= MAX_RETRY.
   - Test impact: none for the audit; if you change this file rerun npm run build and npm test --if-present in ALQASEER-PWA per AGENTS instructions.

2. Surface conflicts/failures in the UI via useOfflineQueue + SyncStatus + VisitsPage
   - Extend the snapshot to include retryCount, nextRetryAt, and the most recent lastError so SyncStatus can render a detail link or badge showing خطأ متكرر and the planned retry time.
   - In VisitsPage show an inline toast whenever lastConflictAt changes so reps know which visit ID/type was dropped; reuse setMessage to close the loop after syncNow.
   - Minimal diff: add derived fields to the QueueSnapshot, pass them to SyncStatus, and update the component markup with a small list (queue count, next retry, conflict link) plus concise Arabic helper text.
   - Test impact: manual PWA verification; no backend changes required.

3. Clarify sync/backoff triggers in useOfflineQueue
   - Guard the online event handler so it does not call syncNow while isSyncing is true and throttle the manual مزامنة الآن button by checking nextRetryAt before replaying.
   - Minimal diff: wrap syncNow in an isSyncing guard and display a short message if nextRetryAt is still in the future instead of re-running the loop.
   - Test impact: none beyond the existing PWA smoke test; just verify the UI still renders sync status.

4. Reconcile the service worker background sync with the manual queue or remove the redundant entry
   - Choose one queue: either keep the Workbox runtime entry and drop the manual queue, or point the background sync handler at the same IndexedDB queue so the two agents do not fight.
   - Minimal diff: remove the third runtimeCaching entry (the POST rule) in vite.config.ts so Workbox no longer replays those posts with a different header.
   - Test impact: rerun npm run build and npm test --if-present in ALQASEER-PWA after changing vite.config.ts to keep the SW manifest valid.

## Testing
- Not run (documentation-only audit). If the above changes are implemented rerun ALQASEER-PWA npm ci, npm run build, and npm test --if-present per AGENTS guidance.
