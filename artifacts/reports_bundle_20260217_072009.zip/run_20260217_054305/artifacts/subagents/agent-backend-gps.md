# Agent-BACKEND-GPS Findings (2026-02-17)

## Audit Summary
- `CRM/backend/api/v1/utils_gps.py` already wraps `validate_accuracy` and `validate_max_distance` in `GPSValidationError` with descriptive details, and `visits.py` plugs those checks into the start/end endpoints. No regression was detected in the validation/error messaging flow.
- The start/end endpoints, however, surfaced a regression for retries: a second `/start` or `/end` hit raised `400` even though the visit was already in the desired state. In practice that means occasional duplicate requests (e.g., network retries) can never succeed, and clients cannot safely replay telemetry once a visit has been recorded. The GPS enforcement itself is correct, but the server-side reactions to duplicate requests were brittle.

## Recommended Changes & Implementation
1. `CRM/backend/api/v1/visits.py`: keep the existing accuracy/geofence/distance guards but short-circuit when the visit already carries a `started_at` or `ended_at`. Instead of raising `400`, log the duplicate and return the persisted visit before attempting any further validation. This keeps the endpoints idempotent while the first request still enforces accuracy/distance.
2. `CRM/backend/tests/test_visits.py`: add regression tests to confirm the new behavior. The duplicate start test replays `POST /visits/{id}/start` with wildly different coordinates (lat/lng/accuracy that would fail if re-validated) and asserts the server returns the original `started_at`. The duplicate end test does the same with a second `POST /visits/{id}/end`, proving that the GPS distance check is not re-run and that the stored `ended_at`/`end_lat` remain untouched.
3. `CRM/backend/tests/test_gps_policy.py` is still exercising the accuracy and distance guards, so the overall GPS enforcement story remains covered.

## Tests
- `py -3.11 -m pytest -q tests/test_visits.py tests/test_gps_policy.py`
