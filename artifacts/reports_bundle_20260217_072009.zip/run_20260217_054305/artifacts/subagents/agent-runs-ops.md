# Agent Runs Ops Audit

## Run gate script (`scripts/run_gates.ps1`)
### Execution order
- Parameters: requires `RunDir`; optionally accepts `CiTruthsJson`, `MaxRetries` (default 3), and output paths.
- Resolves repository root, forces creation of `logs`, `artifacts`, and `json` under the run directory.
- Loads `resolve_python.ps1`, resolves a Python executable, and substitutes that executable for every `python`, `python3`, or `py` command before execution.
- Reads the CI truths JSON (failing fast if missing), then iterates each job/step/line in order. For every command:
  - Resolves the working directory (`غير مذكور` or empty defaults to repo root).
  - Executes each command line inside a `cmd.exe /c` (Windows) or `bash -lc` shell, capturing both stdout/stderr to `logs/gate_<jobId>.log`.
  - Stops the job if a command exits nonzero and retries the job until `MaxRetries` is hit, appending retry markers to the log.
- After every job, captures pass/fail metadata plus attempts, errors, and log path into `artifacts/json/gates.json` and a Markdown summary (`artifacts/GATES.md`). The script exits with 0 only if every job passes.

### Expected outputs
- `logs/gate_<jobId>.log` per job with command traces, retry notices, and error details.
- `json/gates.json` describing `overall_pass`, `python_command`, and each gate record (id/name/pass/attempts/error/log).
- `artifacts/GATES.md` human-readable summary of the same structure.
- Any additional `OutMd`/`OutJson` paths if caller overrides the defaults.

### Risks/notes
- If `RunDir` or `ci_truths.json` is missing, the script terminates immediately with `Write-Error`.
- JSON must follow the expected shape (`jobs[].steps[].run` plus optional `working_directory`), otherwise commands silently skip and gate may pass without work.
- Commands run via unquoted `cmd.exe /c` or `bash -lc`, so shell parsing (quotes, env vars) is dependent on the job author already escaping correctly.
- Python resolution rewrites only the first token; scripts that invoke `python` via an env wrapper or alias may still break.
- `MaxRetries` protects transient failures, but retries re-execute the entire job; long-running job definitions can consume time before failing.
- Because each command is logged but not gated by timestamps or gating metadata, a failing job always returns a non-zero exit code (no soft-fails), which is appropriate for CI but means human investigators must inspect the generated log file for context.

## Missing auto-run script (`docs/_runs/_tmp_full_auto.ps1`)
- `docs/_runs/_tmp_full_auto.ps1` does not currently exist in the workspace (searched the repo root and found no file). If automation subsequently needs it, the run gate workflow cannot reference it until the script is added.

## Related verify script (`tools/CODEX_verify_builds.ps1`)
### Execution order
- `Set-StrictMode`/`$ErrorActionPreference` ensure the script stops on the first failure.
- `Stop-Locks` kills existing `node`, `vite`, and `esbuild` processes to avoid file locks.
- `Remove-DirSafe` removes `node_modules`, `.vite`, and `dist` up to six attempts, yielding if removal fails due to locks after retries and a short sleep.
- For `CRM/frontend`: runs `npm ci`, `npm run build`, then asserts `dist/index.html` exists (throwing if missing).
- For `ALQASEER-PWA`: sets `NODE_ENV=development`, re-runs the cleanup, installs with `npm ci --include=dev`, runs `npm run build`, checks `dist/index.html`, and finally validates that `node_modules/vite/bin/vite.js` still exists.
- Logs/timestamps printed at each `Step` name; after both builds, the script prints the dist locations and a note about the next optional servers step.

### Expected outputs
- Fresh `CRM/frontend/dist/index.html` plus all assets produced by `npm run build`.
- Fresh `ALQASEER-PWA/dist/index.html` built with dev dependencies in place.
- Console output showing the repo path, Node/NPM versions, each step header, and `SUCCESS: Both builds completed.` message.
- The final `Check Vite exists in PWA` step ensures `node_modules` contains `vite/bin/vite.js`, catching partial installs.

### Risks/notes
- The aggressive `Remove-DirSafe` cleaning removes cached artifacts (`node_modules`, `.vite`, `dist`) every run, which increases build time but ensures determinism; if run manually it may evict valuable caches.
- Killing `node`, `vite`, and `esbuild` processes may terminate unrelated local services; run only on dedicated CI agents or after verifying no important processes rely on those names.
- `npm ci --include=dev` assumes the lockfile/bundle is accurate; if `package-lock.json` is out of sync with `devDependencies`, the command will fail fast.
- The script throws visible errors (via `Step`) when any command exits non-zero, but it does not preserve logs beyond what the console provides—collect logs externally if upstream automation needs them.
- `NODE_ENV=development` is explicitly set for the PWA build to include devDependencies; if some automation expects a production-only install, this may need adjustment.

## Deployment conflict note
- `docs/_runs/_archive_reports/run_20260214_225137/artifacts/docs_checklist_conflict.txt` currently retains unresolved merge markers (`<<<<<<< HEAD`, `=======`, `>>>>>>> origin/main`) with duplicated sections outlining Cloudflare Pages SPA routing versus Vercel/TODO instructions. This leaves deploy guidance in flux: the Cloudflare section prescribes `_redirects` and backend CORS checks, while the Vercel section repeats similar content but emphasized Vercel env var setup. Until the conflict is resolved, operators inheriting this file may misinterpret whether Cloudflare or Vercel is the active default, so the doc should be cleaned before being published.
